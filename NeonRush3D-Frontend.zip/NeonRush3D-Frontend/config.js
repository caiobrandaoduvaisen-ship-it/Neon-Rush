// Endereço público do servidor do Neon Rush 3D (Render).
// Troque pelo endereço do seu Web Service, sem barra no final. Exemplo:
// window.NRD_API_URL = 'https://neonrush3d-api.onrender.com';
window.NRD_API_URL = '';
