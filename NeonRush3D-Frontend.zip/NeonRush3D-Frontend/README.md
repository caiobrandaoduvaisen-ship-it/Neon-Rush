# Neon Rush 3D — Jogo (Frontend)

O jogo original, com os sistemas online integrados aos próprios menus.

## Arquivos
- `index.html` — o jogo (original preservado + integrações)
- `config.js` — endereço do servidor (`window.NRD_API_URL`)
- `netlify.toml` — evita cache antigo do `config.js` e do `index.html`
- `backup/index.original.html` — cópia intacta do jogo antes das mudanças
- `DEPLOY_NETLIFY.md` — como publicar

## O que foi adicionado ao jogo
- **👤 ENTRAR / PERFIL**: cadastro, login, logout, sessão lembrada, campo **Código de ativação OWNER**, ID permanente, cargo, saldo, personagens, recordes, conquistas, histórico de compras.
- **Loja (PERSONAGENS)**: 5 novos — Astronauta, Robô R-22, Pirata, Zumbi e Chef — por 50 moedas cada; **CRIADOR** exclusivo de influenciadores.
- **RESGATAR CÓDIGO**: NEONRUN, RAILRSH, TRAVESO (Menino Travesso), YURIZAO (Yuri 22), VERITYY (Verity) + códigos criados pelo OWNER.
- **💬 CHAT**, **✉️ MSGS**, **🔔 notificações**, **🏆 RANK** e **🛡️ GERENCIAR JOGADORES** (só equipe).
- **Mapa**: um trem estacionário com rampa (aparece uma vez por corrida, por volta dos 180 m).
- **Física**: rampa com colisão, pulo com tolerância ao sair do teto, detecção de chão, câmera acompanha a altura.

Sem servidor configurado, tudo continua funcionando offline como antes (moedas e personagens salvos no aparelho).
Quando a conta está conectada, moedas, compras e personagens vêm do servidor.
